package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.Qualifier;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.PbinfoUserSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/features/filter_pbinfo.csv")
public class FilterPbinfoTest {
    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public PbinfoUserSteps user;

    public String clasa;
    public String expectedResultFilter;

    @Test
    public void filterByClassTestDDT() {
        user.open_problems_page();
        user.select_class_and_filter(clasa, expectedResultFilter);
    }
}