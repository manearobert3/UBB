package org.example.steps.serenity;

import net.thucydides.core.annotations.Step;
import org.example.pages.PbinfoPage;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.By;

public class PbinfoUserSteps {
    PbinfoPage pbinfoPage;

    @Step
    public void opens_login_page() {
        pbinfoPage.openLoginPage();
        pbinfoPage.acceptConsentIfPresent();
    }

    @Step
    public void open_problems_page() {
        pbinfoPage.openProblemsPage();
        pbinfoPage.acceptConsentIfPresent();
    }

    @Step
    public void logs_in_with(String username, String password) {
        pbinfoPage.login(username, password);
    }

    @Step
    public void should_see_login_result(String expectedResult) {
        if ("valid".equalsIgnoreCase(expectedResult)) {
            assertThat(pbinfoPage.isLoginFailed(), is(false));
        } else {
            pbinfoPage.waitForAlertDanger();
            assertThat(pbinfoPage.isLoginFailed(), is(true));
        }
    }

    @Step
    public void select_class_and_filter(String clasa, String expectedResult) {
        boolean found = pbinfoPage.trySelectClassAndFilter(clasa);
        if ("invalid".equalsIgnoreCase(expectedResult)) {
            assertThat("Class option should not exist", found, is(false));
        } else {
            assertThat("Class option should exist", found, is(true));
        }
    }
}