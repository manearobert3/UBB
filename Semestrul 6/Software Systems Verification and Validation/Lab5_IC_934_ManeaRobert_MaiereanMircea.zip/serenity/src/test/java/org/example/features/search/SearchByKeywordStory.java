// export MAVEN_OPTS="--add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.base/java.lang.reflect=ALL-UNNAMED --add-opens java.base/java.util=ALL-UNNAMED"
package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Pending;
import net.thucydides.core.annotations.Steps;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import org.example.steps.serenity.EndUserSteps;

@RunWith(SerenityRunner.class)
public class SearchByKeywordStory {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public EndUserSteps anna;

    @Issue("#WIKI-1")
    @Test
    public void searching_by_keyword_apple_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("apple");
        // anna.should_see_de
        // anna.should_see_definition("A common, round fruit produced by the tree Malus
        // domestica, cultivated in temperate climates.");
        // anna.should_see_definition("Rezultatele cautarii dupa: apple");
        anna.should_see_definition(
                "Rachel Appleby: Observations & Reflections: Learning from each other, learning from yourself");

    }

    @Issue("#MANEA")
    @Test
    public void searching_by_keyword_manea_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("manea");
        // anna.should_see_de
        // anna.should_see_definition("A common, round fruit produced by the tree Malus
        // domestica, cultivated in temperate climates.");
        // anna.should_see_definition("Rezultatele cautarii dupa: apple");
        anna.should_see_definition(
                "A 49-a ediție a Școlii de Vară de Limba și Civilizația Româneasca");
    }

    @Issue("#MAIEREAN")
    @Test
    public void searching_by_keyword_maierean_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.looks_for("maierean");
        // anna.should_see_de
        // anna.should_see_definition("A common, round fruit produced by the tree Malus
        // domestica, cultivated in temperate climates.");
        // anna.should_see_definition("Rezultatele cautarii dupa: apple");
        anna.should_see_definition(
                "Culegere admitere Informatică – În atenția candidaților la concursul de admitere 2025, nivel licență");
    }
}