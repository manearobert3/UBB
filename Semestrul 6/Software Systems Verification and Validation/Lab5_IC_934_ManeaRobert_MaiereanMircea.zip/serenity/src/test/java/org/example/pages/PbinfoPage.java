package org.example.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import java.util.List;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.NoSuchElementException;

@DefaultUrl("https://www.pbinfo.ro/")
public class PbinfoPage extends PageObject {

    @FindBy(id = "user")
    WebElement usernameField;

    @FindBy(id = "parola")
    WebElement passwordField;

    @FindBy(css = "#form-login button[type='submit']")
    WebElement loginButton;

    @FindBy(css = "p.fc-button-label")
    WebElement consentButton;

    @FindBy(id = "clasa")
    WebElement classField;

    @FindBy(css = ".right > button")
    WebElement filtrareButton;

    public void openLoginPage() {
        openUrl("https://www.pbinfo.ro/");
    }

    public void openProblemsPage() {
        openUrl("https://www.pbinfo.ro/?pagina=probleme-lista");
    }

    public void login(String username, String password) {
        usernameField.clear();
        usernameField.sendKeys(username);
        passwordField.clear();
        passwordField.sendKeys(password);
        loginButton.click();
    }

    public boolean isLoginFailed() {
        // Check for an error message
        return !findAll(".alert-danger").isEmpty();
    }

    public void acceptConsentIfPresent() {
        List<WebElement> consentButtons = getDriver().findElements(By.cssSelector("p.fc-button-label"));
        if (!consentButtons.isEmpty() && consentButtons.get(0).isDisplayed()) {
            consentButtons.get(0).click();
        }
    }

    public void waitForAlertDanger() {
        waitFor(".alert-danger");
    }

    public void selectClassAndFilter(String clasa) {
        classField.click();
        Select select = new Select(classField);
        select.selectByVisibleText(clasa);
        filtrareButton.click();
    }

    public boolean trySelectClassAndFilter(String clasa) {
        try {
            Select select = new Select(classField);
            select.selectByVisibleText(clasa);
            filtrareButton.click();
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}