package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.Qualifier;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.PbinfoUserSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/features/login_pbinfo.csv")
public class LoginPbinfoTest {
    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public PbinfoUserSteps user;

    public String username;
    public String password;
    public String expectedResult;

    @Qualifier
    public String getQualifier() {
        return username + "-" + password;
    }

    @Test
    public void loginTestDDT() {
        user.opens_login_page();
        user.logs_in_with(username, password);
        user.should_see_login_result(expectedResult);
    }
}