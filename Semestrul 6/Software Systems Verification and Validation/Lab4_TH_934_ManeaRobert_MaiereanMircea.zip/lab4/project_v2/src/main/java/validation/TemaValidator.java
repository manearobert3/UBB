package validation;

import domain.Tema;

public class TemaValidator implements Validator<Tema> {

    /**
     * Valideaza o tema
     * @param entity - tema pe care o valideaza
     * @throws ValidationException daca tema nu e valida
     */
    @Override
    public void validate(Tema entity) throws ValidationException {
        if (entity.getID().equals("") || entity.getID() == null) { // 2
            throw new ValidationException("Numar tema invalid!"); // 3
        }

        if (entity.getDescriere().equals("")){ // 4
            throw new ValidationException("Descriere invalida!"); // 5
        }

        if (entity.getDeadline() < 1 || entity.getDeadline() > 14) { // 6
            throw new ValidationException("Deadlineul trebuie sa fie intre 1-14."); // 7
        }

        if(entity.getPrimire() < 1 || entity.getPrimire() > 14) { // 8
            throw new ValidationException("Saptamana primirii trebuie sa fie intre 1-14."); // 9
        }
    }
}
