import domain.Student;
import domain.Tema;
import domain.Nota;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import repository.StudentXMLRepo;
import repository.TemaXMLRepo;
import repository.NotaXMLRepo;
import service.Service;
import validation.StudentValidator;
import validation.TemaValidator;
import validation.NotaValidator;
import validation.ValidationException;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IntegrationTest {
    @Mock
    StudentXMLRepo studentRepo;
    @Mock
    TemaXMLRepo temaRepo;
    @Mock
    NotaXMLRepo notaRepo;

    StudentValidator studentValidator = new StudentValidator();
    TemaValidator temaValidator = new TemaValidator();
    NotaValidator notaValidator;
    Service service;

    @BeforeEach
    void setUp() {
        notaValidator = new NotaValidator(studentRepo, temaRepo);
        service = new Service(studentRepo, studentValidator, temaRepo, temaValidator, notaRepo, notaValidator);
    }

    @Test
    void testAddStudentAndAssignment() {
        Student student = new Student("100", "Test Student", 931, "test@student.com");
        Tema tema = new Tema("200", "Test Assignment", 10, 8);
        when(studentRepo.save(student)).thenReturn(null);
        when(temaRepo.save(tema)).thenReturn(null);
        assertNull(service.addStudent(student));
        assertNull(service.addTema(tema));
    }

    @Test
    void testAddStudentAssignmentAndGrade() {
        Student student = new Student("101", "Test Student2", 932, "test2@student.com");
        int validWeek = 14; // must be between 1 and 14
        Tema tema = new Tema("201", "Test Assignment2", validWeek, validWeek);
        Nota nota = new Nota("101#201", "101", "201", 9.5, LocalDate.now());
        when(studentRepo.save(student)).thenReturn(null);
        when(temaRepo.save(tema)).thenReturn(null);
        when(studentRepo.findOne("101")).thenReturn(student);
        when(temaRepo.findOne("201")).thenReturn(tema);
        when(notaRepo.save(nota)).thenReturn(null);
        assertNull(service.addStudent(student));
        assertNull(service.addTema(tema));
        double result = service.addNota(nota, "Good job");
        assertEquals(9.5, result, 0.01);
    }

    @Test
    void testAddGradeWithNonexistentStudentOrAssignment() {
        Nota nota = new Nota("999#999", "999", "999", 8.0, LocalDate.now());
        when(studentRepo.findOne("999")).thenReturn(null);
        assertThrows(ValidationException.class, () -> service.addNota(nota, "Should fail"));
    }
}