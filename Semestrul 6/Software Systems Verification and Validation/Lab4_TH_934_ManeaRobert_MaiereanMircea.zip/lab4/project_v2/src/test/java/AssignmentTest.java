import domain.Tema;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import repository.NotaXMLRepo;
import repository.StudentXMLRepo;
import repository.TemaXMLRepo;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;
import validation.ValidationException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AssignmentTest {
    @Mock
    StudentXMLRepo studentRepo;
    @Mock
    TemaXMLRepo temaRepo;
    @Mock
    NotaXMLRepo notaRepo;

    StudentValidator studentValidator = new StudentValidator();
    TemaValidator temaValidator = new TemaValidator();
    NotaValidator notaValidator;
    Service service;

    @BeforeEach
    void setUp() {
        notaValidator = new NotaValidator(studentRepo, temaRepo);
        service = new Service(studentRepo, studentValidator, temaRepo, temaValidator, notaRepo, notaValidator);
    }

    @Test
    void testAddValidAssignment() {
        Tema tema = new Tema("1", "Test Assignment", 10, 8);
        when(temaRepo.save(tema)).thenReturn(null);
        Tema result = service.addTema(tema);
        assertNull(result);
    }

    @Test
    void testAddAssignmentWithEmptyDescription() {
        Tema tema = new Tema("1", "", 10, 8);
        ValidationException exception = assertThrows(ValidationException.class, () -> {
            service.addTema(tema);
        });
        assertEquals("Descriere invalida!", exception.getMessage());
    }

    @Test
    void testAddAssignmentWithInvalidId() {
        Tema tema = new Tema("", "", 10, 8);
        ValidationException exception = assertThrows(ValidationException.class, () -> {
            service.addTema(tema);
        });
        assertEquals("Numar tema invalid!", exception.getMessage());
    }

    @Test
    void testAddAssignmentWithInvalidDeadline() {
        Tema tema = new Tema("1", "Test Assignment", 15, 8);
        ValidationException exception = assertThrows(ValidationException.class, () -> {
            service.addTema(tema);
        });
        assertEquals("Deadlineul trebuie sa fie intre 1-14.", exception.getMessage());
    }

    @Test
    void testAddAssignmentWithInvalidStartWeek() {
        Tema tema = new Tema("1", "Test Assignment", 10, 0);
        ValidationException exception = assertThrows(ValidationException.class, () -> {
            service.addTema(tema);
        });
        assertEquals("Saptamana primirii trebuie sa fie intre 1-14.", exception.getMessage());
    }
}